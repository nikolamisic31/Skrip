<template>
    <div class="gym">
        <div>
            <b-card
            img-src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5N4IidRLIAZpmzXQD_rGg94XTT8dYttIFHw&usqp=CAU"
                    img-alt="Image"
                    img-top
                    tag="article"
                    style="max-width: 21rem;"
                    class="mb-2"
            >
                <b-card-text>
                    <ul>
                        <li>Naziv: {{ gym.name }}</li>
                        <li>Kolicina: {{ gym.address }}</li>
                        <li>Dana: {{ gym.avalible_space}} </li>
                
                    </ul>
                </b-card-text>

                <form v-if="logged"  @submit.prevent="onSubmit">
                    <button type="submit" href="#" variant="primary">Rezervisi</button>
                </form>
            </b-card>
        </div>
    
    </div>

</template>

<script>
import { mapActions,mapState } from 'vuex';

import io from 'socket.io-client'
import store from '../store/index'

let socket = io('http://localhost:7000', {

})

socket.connect()

socket.on('vracen', data => {
  store.commit('addProducts', data)
})

export default {
   name: 'SingleProduct',

   props: {
     gym: Object
   },computed:{
            logged(){
                return this.$store.state.token !== 'izlogovan'
            }
    },
    methods:{
        ...mapActions([
            'rezervisi'
        ]),
        onSubmit(e){
            this.rezervisi({})
            socket.emit('smanji', {
                gym:this.gym.id,
                broj:this.gym.avalible_space - 1 
            })
        }
    }
   
 }

</script>
