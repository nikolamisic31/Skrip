<template>
    <div class="gym">
        <div>
            <b-card
                    img-src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5N4IidRLIAZpmzXQD_rGg94XTT8dYttIFHw&usqp=CAU"
                    img-alt="Image"
                    img-top
                    tag="article"
                    style="max-width: 21rem;"
                    class="mb-2"
            >
                <b-card-text>
                    <ul>
                        <li>Name: {{ gym.name}}</li>
                        <li>Address: {{ gym.address }}</li>
                        <li>Korisnik: {{ gym.korisnikID}}</li>
                        <li>Slobodna mesta: {{ gym.avalible_space }}</li>
                    </ul>
                </b-card-text>
            </b-card>
        </div>
    </div>
</template>

<script>
import { mapActions,mapState } from 'vuex';

import store from '../store/index'

export default {
   name: 'MySingleProduct',

   props: {
     gym: Object
   },computed:{
        logged(){
            return this.$store.state.token !== 'izlogovan'
        }
    },
    methods:{

         onSubmit(e){
             this.fetchMyReservations({})
             socket.emit('smanji', {
                 gym:this.gym.id,
                 broj:this.gym.avalible_space - 1 
             })
         }
    }
  }

</script>
