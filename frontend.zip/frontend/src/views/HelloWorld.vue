<template>
  <!-- Jumbotron -->
  <div
    class="bg-image p-5 text-center shadow-1-strong rounded mb-5 text-white"
    style="background-image: url('https://abcfitness.com/wp-content/uploads/ABC-Corp-1200x630-1-jpg-webp.webp');"
  >
    <br><br><br><br><br>
    <h1 class="mb-3 h2"></h1>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  </div>
  <!-- Jumbotron -->
</template>

<script>
export default {
  name: "HelloWorld",
  props: {
    msg: String,
  },
};
</script>
