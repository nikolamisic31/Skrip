'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
     return queryInterface.bulkInsert('workpeople', [
     {id:"1", name: "Pedja", surname: "Mitic",age: "25", sex: "Men", date_start_working: "2018-10-15", idGym: "2", createdAt: new Date(), updatedAt: new Date()},
     {id:"2", name: "Andjela", surname: "Rajic",age: "27", sex: "Women", date_start_working: "2018-02-10", idGym: "3", createdAt: new Date(), updatedAt: new Date()},
     {id:"3", name: "Marko", surname: "Marjanovic",age: "23", sex: "Men", date_start_working: "2019-05-07", idGym: "5", createdAt: new Date(), updatedAt: new Date()},
     {id:"4", name: "Petar", surname: "Lazic",age: "28", sex: "Men", date_start_working: "2018-08-15", idGym: "1", createdAt: new Date(), updatedAt: new Date()},
     {id:"5", name: "Jelena", surname: "Mitrovic",age: "31", sex: "Women", date_start_working: "2019-03-28", idGym: "4", createdAt: new Date(), updatedAt: new Date()}
     ],
     {});
  },

  async down (queryInterface, Sequelize) {
    return queryInterface.bulkDelete('workpeople', null, {});
  }
};
