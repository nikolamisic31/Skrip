'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.bulkInsert('clients',
      [
        {id: "1", name: "Ivan", surname: "Prlić", numberOfPhone: "0656405589", email: "ivanpr21@gmail.com", idGym: "1", createdAt: new Date(), updatedAt: new Date()},
        {id: "2", name: "Miloš", surname: "Ćirić", numberOfPhone: "0646362521", email: "milosciric1@gmail.com", idGym: "5", createdAt: new Date(), updatedAt: new Date()},
        {id: "3", name: "Petar", surname: "Milanović", numberOfPhone: "0653213268", email: "pmilanovic67@gmail.com", idGym: "4", createdAt: new Date(), updatedAt: new Date()},
        {id: "4", name: "Lazar", surname: "Tolić", numberOfPhone: "0636326262", email: "ltolic19@gmail.com", idGym: "4", createdAt: new Date(), updatedAt: new Date()},
        {id: "5", name: "Nikola", surname: "Mišić", numberOfPhone: "0641999326", email: "nmisic88@gmail.com", idGym: "3", createdAt: new Date(), updatedAt: new Date()},
        {id: "6", name: "Aleksandra", surname: "Krstić", numberOfPhone: "0641511236", email: "aleksandramisic36@gmail.com", idGym: "5", createdAt: new Date(), updatedAt: new Date()},
        {id: "7", name: "Ivana", surname: "Mišić", numberOfPhone: "0633233264", email: "ivanamis7@gmail.com", idGym: "2", createdAt: new Date(), updatedAt: new Date()},
        {id: "8", name: "Aca", surname: "Marković", numberOfPhone: "0656262225", email: "acamarkovic@gmail.com", idGym: "4", createdAt: new Date(), updatedAt: new Date()},
        {id: "9", name: "Milica", surname: "Glišić", numberOfPhone: "0641222458", email: "milicag3@gmail.com", idGym: "4", createdAt: new Date(), updatedAt: new Date()},
        {id: "10", name: "Luka", surname: "Ristić", numberOfPhone: "0641233256", email: "lukaris@gmail.com", idGym: "5", createdAt: new Date(), updatedAt: new Date()},
        {id: "11", name: "Slavica", surname: "Gajić", numberOfPhone: "0647299168", email: "slavicagl17@gmail.com", idGym: "2", createdAt: new Date(), updatedAt: new Date()},
        {id: "12", name: "Goran", surname: "Krajić", numberOfPhone: "0656969624", email: "krajic12@gmail.com", idGym: "3", createdAt: new Date(), updatedAt: new Date()},
        {id: "13", name: "Srđan", surname: "Jeremić", numberOfPhone: "0656262325", email: "sjeremić2020@gmail.com", idGym: "4", createdAt: new Date(), updatedAt: new Date()},
        {id: "14", name: "Pavle", surname: "Janić", numberOfPhone: "0636562144", email: "pjanić1919@gmail.com", idGym: "1", createdAt: new Date(), updatedAt: new Date()},
        {id: "15", name: "David", surname: "Spasić", numberOfPhone: "063333126", email: "spale69@gmail.com", idGym: "1", createdAt: new Date(), updatedAt: new Date()},
        {id: "16", name: "Marko", surname: "Zlatojević", numberOfPhone: "063371699", email: "mzlatojević2321@gmail.com", idGym: "3", createdAt: new Date(), updatedAt: new Date()},
        {id: "17", name: "Ilija", surname: "Paunović", numberOfPhone: "065986215", email: "paun97@gmail.com", idGym: "1", createdAt: new Date(), updatedAt: new Date()},
        {id: "18", name: "Andjelka", surname: "Mitrović", numberOfPhone: "064415444", email: "amitrović@gmail.com", idGym: "3", createdAt: new Date(), updatedAt: new Date()},
        {id: "19", name: "Tanja", surname: "Rajković", numberOfPhone: "062169951", email: "tanjar@gmail.com", idGym: "5", createdAt: new Date(), updatedAt: new Date()},
        {id: "20", name: "Zoran", surname: "Arsenijević", numberOfPhone: "061225946", email: "zoranarsenijevic99@gmail.com", idGym: "1", createdAt: new Date(), updatedAt: new Date()},
        {id: "21", name: "Ana", surname: "Arsenijević", numberOfPhone: "061225946", email: "anarsenijevic99@gmail.com", idGym: "5", createdAt: new Date(), updatedAt: new Date()},
      ], 

      {});
  },

  async down (queryInterface, Sequelize) {
    return queryInterface.bulkDelete('contacts', null, {});
  }
};
