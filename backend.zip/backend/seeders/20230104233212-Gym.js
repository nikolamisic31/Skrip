'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.bulkInsert('gyms', 
    [
      {id: "1", name: "Muscle Planet I", address: "Mladenovac, Milivoja Ristića 20", avalible_space: "200", createdAt: new Date(), updatedAt: new Date()},
      {id: "2", name: "Muscle Planet II", address: "Beograd, Braće Jerković 23", avalible_space: "99", createdAt: new Date(), updatedAt: new Date() },
      {id: "3", name: "Muscle Planet III", address: "Novi Sad, Kralja Petra 45", avalible_space: "145", createdAt: new Date(), updatedAt: new Date() },
      {id: "4", name: "Muscle Planet IV", address: "Kragujevac, Mihajla Ristića 4", avalible_space: "209", createdAt: new Date(), updatedAt: new Date() },
      {id: "5", name: "Muscle Planet V", address: "Čačak, Miloša Živkovića 12", avalible_space: "85", createdAt: new Date(), updatedAt: new Date() },
      {id: "6", name: "Muscle Planet VI", address: "Svrljjig, Paje Jovica 15", avalible_space: "35", createdAt: new Date(), updatedAt: new Date() }
    ], 
    {});
  },

  async down (queryInterface, Sequelize) {
    return queryInterface.bulkDelete('gyms', null, {});
  }
};
