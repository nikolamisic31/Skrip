"use strict";

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert("Korisniks", [
      {
        id: "1",
        ime: "nikola",
        prezime: "misic",
        email: "nmisic3120rn@raf.rs",
        sifra: "admin",
        admin: true,
        moderator: false,
      },
      {
        id: "2",
        ime: "pera",
        prezime: "peric",
        email: "pera@gmail.com",
        sifra: "peric",
        admin: false,
        moderator: true,
      },
      {
        id: "3",
        ime: "marko",
        prezime: "markovic",
        email: "marko@gmail.com",
        sifra: "markovic",
        admin: false,
        moderator: true,
      },
      {
        id: "4",
        ime: "katarina",
        prezime: "katic",
        email: "katarina@gmail.com",
        sifra: "katic",
        admin: false,
        moderator: false,
      },
      {
        id: "5",
        ime: "marija",
        prezime: "markovic",
        email: "marija@gmail.com",
        sifra: "markovic",
        admin: false,
        moderator: false,
      },
      {
        id: "6",
        ime: "lazar",
        prezime: "lazarevic",
        email: "lazar@gmail.com",
        sifra: "lazarevic",
        admin: false,
        moderator: false,
      },
      {
        id: "7",
        ime: "aleksa",
        prezime: "aleksic",
        email: "aleksa@gmail.com",
        sifra: "aleksic",
        admin: false,
        moderator: false,
      },
    ]);
  },

  async down(queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
  },
};
