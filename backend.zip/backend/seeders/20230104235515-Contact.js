'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.bulkInsert('contacts', 
    [
      {id: "1", phoneNumber: "0641655316", email: "muslcePlanetOne123@gmail.com", facebook: "Muslce Planet I", instagram: "muslce_planet_I", idGym: "1",createdAt: new Date(), updatedAt: new Date()},
      {id: "2", phoneNumber: "0656460642", email: "muslcePlanetTwo63@gmail.com", facebook: "Muslce Planet II", instagram: "muslce_planet_II", idGym: "2",createdAt: new Date(), updatedAt: new Date()},
      {id: "3", phoneNumber: "0633930364", email: "muslcePlanetThree777@gmail.com", facebook: "Muslce Planet III", instagram: "muslce_planet_III", idGym: "3",createdAt: new Date(), updatedAt: new Date()},
      {id: "4", phoneNumber: "0641999326", email: "muslcePlanetoFour1@gmail.com", facebook: "Muslce Planet IV", instagram: "muslce_planet_IV", idGym: "4",createdAt: new Date(), updatedAt: new Date()},
      {id: "5", phoneNumber: "0656145458", email: "muslcePlanetFive111@gmail.com", facebook: "Muslce Planet V", instagram: "muslce_planet_V", idGym: "5",createdAt: new Date(), updatedAt: new Date()},
    
    ], 
    {});
  },

  async down (queryInterface, Sequelize) {
    return queryInterface.bulkDelete('contacts', null);
  }
};
