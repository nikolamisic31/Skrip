'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
     return queryInterface.bulkInsert('membership_cards', [
      {id:"1", name: "gold", number_of_arrivals: "30", sale: "15%", idClient: "5",createdAt: new Date(), updatedAt: new Date()},
      {id:"2", name: "silver", number_of_arrivals: "25", sale: "10%", idClient: "10",createdAt: new Date(), updatedAt: new Date()},
      {id:"3", name: "bronse", number_of_arrivals: "15", sale: "5%", idClient: "15",createdAt: new Date(), updatedAt: new Date()},
      {id:"4", name: "silver", number_of_arrivals: "17", sale: "10%", idClient: "20",createdAt: new Date(), updatedAt: new Date()},
      {id:"5", name: "bronse", number_of_arrivals: "5", sale: "5%", idClient: "2",createdAt: new Date(), updatedAt: new Date()},
      {id:"6", name: "bronse", number_of_arrivals: "6", sale: "5%", idClient: "8",createdAt: new Date(), updatedAt: new Date()},
      {id:"7", name: "gold", number_of_arrivals: "17", sale: "15%", idClient: "4",createdAt: new Date(), updatedAt: new Date()},
      {id:"8", name: "gold", number_of_arrivals: "26", sale: "15%", idClient: "6",createdAt: new Date(), updatedAt: new Date()},
      {id:"9", name: "gold", number_of_arrivals: "14", sale: "15%", idClient: "12",createdAt: new Date(), updatedAt: new Date()},
      {id:"10", name: "silver", number_of_arrivals: "30", sale: "10%", idClient: "18",createdAt: new Date(), updatedAt: new Date()},
      {id:"11", name: "gold", number_of_arrivals: "29", sale: "15%", idClient: "14",createdAt: new Date(), updatedAt: new Date()},
      {id:"12", name: "bronse", number_of_arrivals: "21", sale: "5%", idClient: "21",createdAt: new Date(), updatedAt: new Date()},
      {id:"13", name: "silver", number_of_arrivals: "18", sale: "10%", idClient: "16",createdAt: new Date(), updatedAt: new Date()},
      {id:"14", name: "silver", number_of_arrivals: "7", sale: "10%", idClient: "1",createdAt: new Date(), updatedAt: new Date()},
      {id:"15", name: "bronse", number_of_arrivals: "28", sale: "5%", idClient: "3",createdAt: new Date(), updatedAt: new Date()},
      {id:"16", name: "gold", number_of_arrivals: "14", sale: "15%", idClient: "9",createdAt: new Date(), updatedAt: new Date()},
      {id:"17", name: "bronse", number_of_arrivals: "6", sale: "5%", idClient: "7",createdAt: new Date(), updatedAt: new Date()},
      {id:"18", name: "bronse", number_of_arrivals: "25", sale: "5%", idClient: "17",createdAt: new Date(), updatedAt: new Date()},
      {id:"19", name: "bronse", number_of_arrivals: "21", sale: "5%", idClient: "11",createdAt: new Date(), updatedAt: new Date()},
      {id:"20", name: "gold", number_of_arrivals: "17", sale: "15%", idClient: "19",createdAt: new Date(), updatedAt: new Date()},
      {id:"21", name: "silver", number_of_arrivals: "14", sale: "10%", idClient: "13",createdAt: new Date(), updatedAt: new Date()}
    ],
    {});
    
  },

  async down (queryInterface, Sequelize) {
     return queryInterface.bulkDelete('membership_cards', null, {});
  }
};
