'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.bulkInsert('impressions', 
    [
      {id:"1",comment: "Sve pohvale za teretanu, čista, sve najelpše", time_impression: "17:38", date_impression: "2022-08-23",idClient: "7",  createdAt: new Date(), updatedAt: new Date()},
      {id:"2",comment: "Teretana je opreljmljena svim spravama, sve pohvale", time_impression: "09:13", date_impression: "2022-06-14",idClient: "1",  createdAt: new Date(), updatedAt: new Date()},
      {id:"3",comment: "Organizacija je mogo dobra, usluga je odlicna, sve pohvale", time_impression: "10:49", date_impression: "2021-07-25",idClient: "8",  createdAt: new Date(), updatedAt: new Date()},
      {id:"4",comment: "Velika guzva, ali ovako sve pohvale", time_impression: "16:23", date_impression: "2021-03-06",idClient: "19",  createdAt: new Date(), updatedAt: new Date()},
      {id:"5",comment: "Higijena je na nivou, svlacionice opremljene...", time_impression: "20:16", date_impression: "2022-07-07",idClient: "15",  createdAt: new Date(), updatedAt: new Date()},
      {id:"6",comment: "Izvrsno.", time_impression: "16:10", date_impression: "2021-10-05",idClient: "4",  createdAt: new Date(), updatedAt: new Date()},
      {id:"7",comment: "Dobro podučeni treneri, sve pohvale za njih", time_impression: "20:20", date_impression: "2021-10-31",idClient: "21",  createdAt: new Date(), updatedAt: new Date()},
      {id:"8",comment: "Vrlo povoljne cene, odlicno odradjena organizacija, osobe vrlo pedantno", time_impression: "11:55", date_impression: "2021-02-12",idClient: "11",  createdAt: new Date(), updatedAt: new Date()},
      {id:"9",comment: "Sve pohvale...", time_impression: "18:45", date_impression: "2020-05-16", idClient: "2", createdAt: new Date(), updatedAt: new Date()},
      {id:"10",comment: "Higijena je na nivou, svlacionice opremljene...", time_impression: "10:21", date_impression: "2021-07-03", idClient: "9", createdAt: new Date(), updatedAt: new Date()},
      {id:"11",comment: "Dobro podučeni treneri, sve pohvale za njih", time_impression: "12:41", date_impression: "2020-10-23", idClient: "13", createdAt: new Date(), updatedAt: new Date()}
  ],
    {});
  },

  async down (queryInterface, Sequelize) {
    return queryInterface.bulkDelete('impressions', null, {});
  }
};
