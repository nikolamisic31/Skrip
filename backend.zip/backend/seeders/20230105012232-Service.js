'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.bulkInsert('services', [
    {id: "1", name: "zumba", service_duration: "60 minutes", idGym: "3", idClient: "14", idWorkpeople: "2", createdAt: new Date(), updatedAt: new Date()},
    {id: "2", name: "zumba", service_duration: "60 minutes", idGym: "5", idClient: "10", idWorkpeople: "2", createdAt: new Date(), updatedAt: new Date()},
    {id: "3", name: "cardio", service_duration: "90 minutes", idGym: "1", idClient: "7", idWorkpeople: "1", createdAt: new Date(), updatedAt: new Date()},
    {id: "4", name: "muscle", service_duration: "75 minutes", idGym: "2", idClient: "8", idWorkpeople: "4", createdAt: new Date(), updatedAt: new Date()},
    {id: "5", name: "cardio", service_duration: "90 minutes", idGym: "5", idClient: "15", idWorkpeople: "1", createdAt: new Date(), updatedAt: new Date()},
    {id: "6", name: "muscle", service_duration: "75 minutes", idGym: "4", idClient: "3", idWorkpeople: "5", createdAt: new Date(), updatedAt: new Date()},
    {id: "7", name: "zumba", service_duration: "60 minutes", idGym: "4", idClient: "1", idWorkpeople: "2", createdAt: new Date(), updatedAt: new Date()},
    {id: "8", name: "cardio", service_duration: "90 minutes", idGym: "1", idClient: "21", idWorkpeople: "1", createdAt: new Date(), updatedAt: new Date()},
    {id: "9", name: "muscle", service_duration: "75 minutes", idGym: "3", idClient: "11", idWorkpeople: "4", createdAt: new Date(), updatedAt: new Date()},
    {id: "10", name: "cardio", service_duration: "90 minutes", idGym: "5", idClient: "12", idWorkpeople: "1", createdAt: new Date(), updatedAt: new Date()}
    
  ],
    {});
    
  },

  async down (queryInterface, Sequelize) {
    return queryInterface.bulkDelete('services', null, {});

  }
};
