'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.bulkInsert('appointments', [
    {id: "1", appointement_time: "10:00", appointment_date: "2023-01-01", idService: "3",createdAt: new Date(), updatedAt: new Date()},
    {id: "2", appointement_time: "11:30", appointment_date: "2022-12-14", idService: "6",createdAt: new Date(), updatedAt: new Date()},
    {id: "3", appointement_time: "13:00", appointment_date: "2022-12-20", idService: "9",createdAt: new Date(), updatedAt: new Date()},
    {id: "4", appointement_time: "14:30", appointment_date: "2023-01-22", idService: "2",createdAt: new Date(), updatedAt: new Date()},
    {id: "5", appointement_time: "16:00", appointment_date: "2022-11-14", idService: "4",createdAt: new Date(), updatedAt: new Date()},
    {id: "6", appointement_time: "17:30", appointment_date: "2023-01-20", idService: "8",createdAt: new Date(), updatedAt: new Date()},
    {id: "7", appointement_time: "19:00", appointment_date: "2023-01-30", idService: "6",createdAt: new Date(), updatedAt: new Date()},
    {id: "8", appointement_time: "20:30", appointment_date: "2022-12-10", idService: "1",createdAt: new Date(), updatedAt: new Date()},
    {id: "9", appointement_time: "21:30", appointment_date: "2023-01-02", idService: "4",createdAt: new Date(), updatedAt: new Date()},
    {id: "10", appointement_time: "09:00", appointment_date: "2023-12-21", idService: "3",createdAt: new Date(), updatedAt: new Date()}
    ],
    {});
  },

  async down (queryInterface, Sequelize) {
    return queryInterface.bulkDelete('appointments', null, {});
  }
};
