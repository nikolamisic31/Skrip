'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.bulkInsert('webshops', [
    {id: "1", product: "T-shirt", price: "1000", idGym: "2", createdAt: new Date(), updatedAt: new Date()},
    {id: "2", product: "Shorts", price: "1500", idGym: "3", createdAt: new Date(), updatedAt: new Date()},
    {id: "3", product: "Socks", price: "500", idGym: "4", createdAt: new Date(), updatedAt: new Date()},
    {id: "4", product: "Towel", price: "2500", idGym: "1", createdAt: new Date(), updatedAt: new Date()},
    {id: "5", product: "Gloves", price: "1200", idGym: "3", createdAt: new Date(), updatedAt: new Date()},
    {id: "6", product: "Sneakers", price: "5000", idGym: "5", createdAt: new Date(), updatedAt: new Date()},
    {id: "7", product: "Hat", price: "3000", idGym: "4", createdAt: new Date(), updatedAt: new Date()},
    ],
   {});
  }, 

  async down (queryInterface, Sequelize) {
    return queryInterface.bulkDelete('webshops', null, {});
  }
};
