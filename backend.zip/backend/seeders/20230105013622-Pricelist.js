'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.bulkInsert('pricelists', [
    {id: "1", price: "2500", idService: "2", createdAt: new Date(), updatedAt: new Date()},
    {id: "2", price: "3000", idService: "4", createdAt: new Date(), updatedAt: new Date()},
    {id: "3", price: "2000", idService: "5", createdAt: new Date(), updatedAt: new Date()},
    {id: "4", price: "2000", idService: "3", createdAt: new Date(), updatedAt: new Date()},
    {id: "5", price: "2500", idService: "7", createdAt: new Date(), updatedAt: new Date()},
    {id: "6", price: "2000", idService: "8", createdAt: new Date(), updatedAt: new Date()},
    {id: "7", price: "3000", idService: "6", createdAt: new Date(), updatedAt: new Date()}
    ],
    {});
  },

  async down (queryInterface, Sequelize) {
    return queryInterface.bulkDelete('pricelists', null, {});
  }
};
