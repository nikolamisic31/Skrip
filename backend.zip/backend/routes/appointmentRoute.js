const { sequelize, Appointment } = require("../models");
const express = require("express");

const route = express.Router();
route.use(express());
route.use(express.json());
route.use(express.urlencoded({ extended: true }));

route.get("/", async (req, res) => {
  try {
    const prom = await Appointment.findAll({
      attributes: ["id","appointment_time", "appointment_date", "idService"],
    });
    res.json(prom);
  } catch {
    
    res.status(500).json({ error: "Greska" });
  }
});

route.get("/:id", async (req, res) => {
  try {
    const prom = await Appointment.findByPk(req.params.id);
    return res.json(prom);
  } catch {
    res.status(500).json({ error: "Greska" });
  }
});

route.post("/", async (req, res) => {
  try {
    let prom = await Appointment.create(req.body);
    res.send(prom);
  } catch {
    res.status(500).json({ error: "Greska"});
  }
});

route.put("/:id", async (req, res) => {
  Appointment.findOne({ where: { id: req.params.id } }).then((prom) => {
    prom.appointment_time = req.body.appointment_time;
    prom.appointment_date = req.body.appointment_date;
    prom.idService = req.body.idService;

    prom
      .save()
      .then((prom) => res.json(prom))
      .catch((err) => res.status(500).json(err));
  });
});

route.delete("/:id", async (req, res) => {
  try {
    let prom = await Appointment.findByPk(req.params.id);
    await prom.destroy();
    res.send(prom);
  } catch {
    res.status(500).json({ error: "Greska"});
  }
});

module.exports = route;
