const { sequelize, Gym } = require("../models");
const express = require("express");

const route = express.Router();
route.use(express.json());
route.use(express.urlencoded({ extended: true }));

route.get("/", async (req, res) => {
  try {
    const prom = await Gym.findAll({
      attributes: ["id", "name", "address","avalible_space"],
    });
    res.json(prom);
  } catch {
    console.log(err);
    res.status(500).json({ error: "Greska" });
  }
});

route.get("/:id", async (req, res) => {
  try {
    const prom = await Gym.findByPk(req.params.id);
    return res.json(prom);
  } catch {
    res.status(500).json({ error: "Greska" });
  }
});

route.post("/", async (req, res) => {
  try {
    let prom = await Gym.create(req.body);
    res.send(prom);
  } catch {
    res.status(500).json({ error: "Greska" });
  }
});

route.put("/:id", async (req, res) => {
  Gym.findOne({ where: { id: req.params.id } }).then((prom) => {
    prom.name = req.body.name;
    prom.address = req.body.address;
    prom.avalible_space = req.body.avalible_space;

    prom
      .save()
      .then((prom) => res.json(prom))
      .catch((err) => res.status(500).json(err));
  });
});

route.delete("/:id", async (req, res) => {
  try {
    let prom = await Gym.findByPk(req.params.id);
    await prom.destroy();
    res.send(prom);
  } catch {
    res.status(500).json({ error: "Greska" });
  }
});

module.exports = route;
