const { sequelize, Pricelist, Korisnik } = require("../models");
const express = require("express");

const route = express.Router();
route.use(express());
route.use(express.json());
route.use(express.urlencoded({ extended: true }));
require('dotenv').config()
const jtw = require('jsonwebtoken')

function authenticateToken(req, res, next){

    const authHeader = req.headers['authorization']
    const token = authHeader && authHeader.split(' ')[1]
    if (token == null) res.sendStatus(401)

    jtw.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user)=>{
        if (err) return res.sendStatus(403)
        req.user = user
        next()
    })
}

route.get("/", authenticateToken, (req, res) => {


  Korisnik.findOne({
    where:{
        ime:req.user.ime
    }
  })
    .then(usr => {

        Pricelist.findAll({
            where:{
                korisnikID: usr.id
            }
        })
            .then(
                rows => {
                    rows = rows.map(el =>{
                        const { ...newObj} = el.dataValues
                        return newObj
                    })
                    res.json(rows)
                }
            )
            .catch(
                err => res.status(500).json(err)
            )
    })
});

// route.get("/:id", async (req, res) => {
//   try {
//     const prom = await Racun.findByPk(req.params.id);
//     return res.json(prom);
//   } catch {
//     res.status(500).json({ error: "Greska" });
//   }
// });

route.post("/",authenticateToken ,async (req, res) => {
  try {
    let prom = await Pricelist.create({
      price: '1500',
      idService: req.user.id,
    });
    res.send(prom);
  } catch {
    res.status(500).json({ error: "Greska" });
  }
});

route.put("/:id", async (req, res) => {
  Pricelist.findOne({ where: { id: req.params.id } }).then((prom) => {
    prom.price = req.body.price;
    prom.idService = req.body.idService;

    prom
      .save()
      .then((prom) => res.json(prom))
      .catch((err) => res.status(500).json(err));
  });
});

route.delete("/:id", async (req, res) => {
  try {
    let prom = await Pricelist.findByPk(req.params.id);
    await prom.destroy();
    res.send(prom);
  } catch {
    res.status(500).json({ error: "Greska" });
  }
});

module.exports = route;
