const { sequelize, Workpeople } = require("../models");
const express = require("express");

const route = express.Router();
route.use(express());
route.use(express.json());
route.use(express.urlencoded({ extended: true }));

route.get("/", async (req, res) => {
  try {
    const prom = await Workpeople.findAll({
      attributes: ["id", "name", "surname", "age", "sex", "date_start_working", "idGym"],
    });
    res.json(prom);
  } catch {
    console.log(err);
    res.status(500).json({ error: "Greska"});
  }
});

route.get("/:id", async (req, res) => {
  try {
    const prom = await Workpeople.findByPk(req.params.id);
    return res.json(prom);
  } catch {
    res.status(500).json({ error: "Greska"});
  }
});

route.post("/", async (req, res) => {
  try {
    let prom = await Workpeople.create(req.body);
    res.send(prom);
  } catch {
    res.status(500).json({ error: "Greska"});
  }
});

route.put("/:id", async (req, res) => {
  Workpeople.findOne({ where: { id: req.params.id } }).then((prom) => {
    prom.name = req.body.name;
    prom.surname = req.body.surname;
    prom.age = req.body.age;
    prom.sex = req.body.sex;
    prom.date_start_working = req.body.date_start_working;
    prom.idGym = req.body.idGym;

    prom
      .save()
      .then((prom) => res.json(prom))
      .catch((err) => res.status(500).json(err));
  });
});

route.delete("/:id", async (req, res) => {
  try {
    let prom = await Workpeople.findByPk(req.params.id);
    await prom.destroy();
    res.send(prom);
  } catch {
    res.status(500).json({ error: "Greska"});
  }
});

module.exports = route;
