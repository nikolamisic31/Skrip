'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Service extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate({Gym, Client, Workpeople, Pricelist, Appointment}) {
      this.belongsTo(Gym, {foreignKey: 'idGym', as: 'gym'});
      this.belongsTo(Client, {foreignKey: 'idClient', as: 'client'});
      this.belongsTo(Workpeople, {foreignKey: 'idWorkpeople', as: 'workpeople'});
      this.hasOne(Pricelist, {foreignKey: 'idService', as: 'pricelist'});
      this.hasMany(Appointment, {foreignKey: 'idService', as: 'appointement'});
    }
  }
  Service.init({
    name:{
      type: DataTypes.STRING,
      allowNull: false
    },
    service_duration:{
      type: DataTypes.STRING,
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'Service',
  });
  return Service;
};