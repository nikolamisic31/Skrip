'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Appointment extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate({Service}) {
      this.belongsTo(Service, {foreignKey: 'idService', as: 'services'});
    }
  }
  Appointment.init({
    appointement_time:{
      type: DataTypes.TIME,
      allowNull: false
    },
    appointment_date:{
      type: DataTypes.DATEONLY,
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'Appointment',
  });
  return Appointment;
};