'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Gym extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate({Contact, Client, Service, Webshop, Workpeople}) {
      this.hasOne(Contact, {foreignKey: 'idGym', as: 'contact'});
      this.hasMany(Client, {foreignKey: 'idGym', as: 'client'});
      this.hasMany(Service, {foreignKey: 'idGym', as: 'service'});
      this.hasOne(Webshop, {foreignKey: 'idGym', as: 'webshop'});
      this.hasMany(Workpeople, {foreignKey: 'idGym', as: 'workpeople'});
    }
  }
  Gym.init({
    name:{
      type: DataTypes.STRING,
      allowNull: false
    },
    address:{
      type: DataTypes.STRING,
      allowNull: false
    },
    avalible_space: {
      type: DataTypes.STRING,
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'Gym',
  });
  return Gym;
};