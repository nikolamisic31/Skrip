'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Membership_card extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate({Client}) {
      this.belongsTo(Client, {foreignKey: 'idClient', as: 'client'});
    }
  }
  Membership_card.init({
    name:{
      type: DataTypes.STRING,
      allowNull: false
    },
    number_of_arrivals:{
      type: DataTypes.INTEGER,
      allowNull: false
    },
    sale:{
      type: DataTypes.STRING,
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'Membership_card',
  });
  return Membership_card;
};