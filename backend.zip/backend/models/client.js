'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Client extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate({Gym, Impression,Membership_card, Service}) {
      this.belongsTo(Gym, {foreignKey: 'idGym', as: 'gym'});
      this.hasMany(Impression, {foreignKey: 'idClient', as: 'impression'});
      this.hasOne(Membership_card, {foreignKey:'idClient', as: 'membership_card'});
      this.hasOne(Service, {foreignKey: 'idClient', as: 'service'});
    }
  }
  Client.init({
    name:{
      type: DataTypes.STRING,
      allowNull: false
    },
    surname:{
      type: DataTypes.STRING,
      allowNull: false
    },
    numberOfPhone:{
      type: DataTypes.INTEGER,
      allowNull: false
    },
    email:{
      type: DataTypes.STRING,
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'Client',
  });
  return Client;
};