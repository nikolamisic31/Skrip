'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Impression extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate({Client}) {
      this.belongsTo(Client, {foreignKey: 'idClient', as: 'client'});
    }
  }
  Impression.init({
    comment:{
      type: DataTypes.STRING,
      allowNull: false
    },
    time_impression:{
      type: DataTypes.TIME,
      allowNull: false
    },
    date_impression:{
      type: DataTypes.DATEONLY,
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'Impression',
  });
  return Impression;
};