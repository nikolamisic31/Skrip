const path = require("path");
const express = require("express");
const cors = require("cors");
const {
  sequelize,
  Appointment,
  Client,
  Gym,
  Contact,
  Impression,
  Korisnik,
  Membership_card,
  Pricelist,
  Service,
  Webshop,
  Workpeople,
} = require("./models");

const { Server } = require('socket.io')
const http = require('http')
//const {sequelize, Aranzman} = require('./models')
const app = express();
const server = http.createServer(app)
const io = new Server(server, {
    cors: {
        origin: '*',
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
        credentials: true
    },
    allowEIO3: true
})

let corsOptions = {
  origin: "*",
  optionSuccessStatus: 200,
};

const dist= path.join(__dirname, './dist')

app.use('/', express.static(dist))

io.on('connection', socket => {
  socket.on('smanji', data => {
    console.log(data)
      Gym.findOne({
          where:{
            id: data.gym
          }
      })
        .then(el => {
            el.avalible_space = data.broj
            el.save()

            Gym.findAll()
              .then(
                  rows => {
                      rows = rows.map(el =>{
                          const { ...newObj} = el.dataValues
                          return newObj
                      })
                        socket.emit('vracen', rows)
                  }
              )
        })
  })
})

app.use(express.json());
app.use(cors(corsOptions));

const gymRoute = require("./routes/gymRoute.js");
app.use("/admin/gym", gymRoute);

const appointmentRoute = require("./routes/appointmentRoute.js");
app.use("/admin/appointment", appointmentRoute);

const clientRoute = require("./routes/clientRoute.js");
app.use("/admin/client", clientRoute);

const contactRoute = require("./routes/contactRoute.js");
app.use("/admin/contact", contactRoute);

const impressionRoute = require("./routes/impressionRoute.js");
app.use("/admin/impression", impressionRoute);

const korisnikRoute = require("./routes/korisnikRoute.js");
app.use("/admin/korisnik", korisnikRoute);

const membership_cardRoute = require("./routes/membership_cardRoute.js");
app.use("/admin/membership_card", membership_cardRoute);

const pricelistRoute = require("./routes/pricelistRoute.js");
app.use("/admin/pricelist", pricelistRoute);

const serviceRoute = require("./routes/serviceRoute.js");
app.use("/admin/service", serviceRoute);

const webshopRoute = require("./routes/webshopRoute.js");
app.use("/admin/webshop", webshopRoute);

const workpeopleRoute = require("./routes/workpeopleRoute.js");
const exp = require("constants");
app.use("/admin/workpeople", workpeopleRoute);

// app.listen({ port: 7000 }, async () => {
//   console.log("REST started on port 7000");
// });
server.listen({port:process.env.PORT || 7000}),async ()=>{
  await sequelize.authenticate();
}