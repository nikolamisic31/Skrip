const express = require("express");
const path = require("path");
// const bcrypt = require("bcrypt");
const jtw = require("jsonwebtoken");
const cors = require("cors");
const { sequelize, Korisnik } = require("./models");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use(cors());

app.use(express.static(path.join(__dirname, "static")));

function getCookie(req) {
  const cookies = req.headers.cookie.split("; ");
  const parsedCookies = {};

  cookies.forEach((element) => {
    pc = element.split("=");
    parsedCookies[pc[0]] = pc[1];
  });

  return parsedCookies;
}

function authToken(req, res, next) {
  const cookies = getCookie(req);
  const token = cookies["token"];
  if (token === null) return res.sendStatus(401);

  jtw.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

app.get("/admin", authToken, (req, res) => {
  res.sendFile("home.html", { root: "static" });
});

app.get("/login", (req, res) => {
  res.sendFile("login.html", { root: "static" });
});

app.get("/register", (req, res) => {
  res.sendFile("register.html", { root: "static" });
});

app.get("/admin/appointment", authToken, (req, res) => {
  res.sendFile("appointmentPage.html", { root: "static" });
});

app.get("/admin/client", authToken, (req, res) => {
  res.sendFile(path.join(__dirname, "static", "clientPage.html"));
});

app.get("/admin/contact", authToken, (req, res) => {
  res.sendFile(path.join(__dirname, "static", "contactPage.html"));
});

app.get("/admin/gym", authToken, (req, res) => {
  res.sendFile(path.join(__dirname, "static", "gymPage.html"));
});

app.get("/admin/impression", authToken, (req, res) => {
  res.sendFile(path.join(__dirname, "static", "impressionPage.html"));
});

app.get("/admin/korisnik", authToken, (req, res) => {
  res.sendFile(path.join(__dirname, "static", "korisnik.html"));
});

app.get("/admin/membership_card", authToken, (req, res) => {
  res.sendFile(path.join(__dirname, "static", "membership_cardPage.html"));
});

app.get("/admin/pricelist", authToken, (req, res) => {
  res.sendFile(path.join(__dirname, "static", "pricelistPage.html"));
});

app.get("/admin/service", authToken, (req, res) => {
  res.sendFile(path.join(__dirname, "static", "servicePage.html"));
});

app.get("/admin/webshop", authToken, (req, res) => {
  res.sendFile(path.join(__dirname, "static", "webshopPage.html"));
});

app.get("/admin/workpeople", authToken, (req, res) => {
  res.sendFile(path.join(__dirname, "static", "workpeoplePage.html"));
});

app.listen({ port: 8000 }, async () => {
  // await sequelize.authenticate();
  console.log("APP started on port 8000");
});
