function init() {
    const token = localStorage.getItem("token");
    if(!token) window.location.href = "/admin/login";

    document.getElementById('serviceBtnGet').addEventListener('click', e => {
        e.preventDefault();
        read();
    })

    document.getElementById('serviceBtnPost').addEventListener('click', e => {
    e.preventDefault();

    const data = {
        name: document.getElementById('name').value,
        service_duration: document.getElementById('service_duration').value
    };

        document.getElementById('name').value = '';
        document.getElementById('service_duration').value = '';

    fetch('http://localhost:7000/admin/service', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}` },
        body: JSON.stringify(data)
        }).then( res => read());
        
    });

    document.getElementById('serviceBtnDelete').addEventListener('click', e => {
    e.preventDefault();

    const data = {
        id: document.getElementById('id').value
    };

    document.getElementById('id').value = '';

    fetch('http://localhost:7000/admin/service/' + data.id, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`},
        body: JSON.stringify(data)
            }). then(res => read());

    });
    document.getElementById('serviceBtnPut').addEventListener('click', e => {
    e.preventDefault();

    const data = {
        id: document.getElementById('id_service').value,
        name: document.getElementById('name_service').value,
        service_duration: document.getElementById('service_duration_service').value

    };
        document.getElementById('id_service').value = '';
        document.getElementById('name_service').value = '';
        document.getElementById('service_duration_service').value = '';

    fetch('http://localhost:7000/admin/service/' + data.id, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}` },
        body: JSON.stringify(data)
        }).then( res => read());
    });
    document.getElementById('logout').addEventListener('click', e => {
        localStorage.setItem("token", {});
        window.location.href = '/admin/login';
    });

}
function read(){
    fetch('http://localhost:7000/admin/service', {
        headers: {
            'Authorization': `Bearer ${localStorage.getItem("token")}`
        }
    })
    .then( res => res.json() )
    .then( data => {
    const lst = document.getElementById('serviceLst');
    lst.remove();

    document.getElementById("service").innerHTML += '<ul id="serviceLst"></ul>';
    const lista = document.getElementById('serviceLst');
    data.forEach( el => {
        lista.innerHTML += `<li>ID: ${el.id}, Name: ${el.name}, Service duration: ${el.service_duration}</li>`;
        });
    });
}