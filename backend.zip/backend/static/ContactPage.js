const token = localStorage.getItem("token");
if(!token) window.location.href = "/admin/login";
function init() {
    
    document.getElementById('contactBtnGet').addEventListener('click', e => {
        e.preventDefault();
        read();
    })

    document.getElementById('contactBtnPost').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            phoneNumber: document.getElementById('phoneNumber').value,
            email: document.getElementById('email').value,
            facebook: document.getElementById('facebook').value,
            instagram: document.getElementById('instagram').value
        };

        document.getElementById('phoneNumber').value = '';
        document.getElementById('email').value = '';
        document.getElementById('facebook').value = '';
        document.getElementById('instagram').value = '';

        fetch('http://localhost:7000/admin/contact', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}` },
            body: JSON.stringify(data)
        }).then( res => read());
            
    });

    document.getElementById('contactBtnDelete').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            id: document.getElementById('id').value
        };

        document.getElementById('id').value = '';

        fetch('http://localhost:7000/admin/contact/' + data.id, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}` },
            body: JSON.stringify(data)
        }). then(res => read());

    });
    document.getElementById('contactBtnPut').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            id: document.getElementById('id_contact').value,
            phoneNumber: document.getElementById('phoneNumber_contact').value,
            email: document.getElementById('email_contact').value,
            facebook: document.getElementById('facebook_contact').value,
            instagram: document.getElementById('instagram_contact').value
        };

        document.getElementById('id_contact').value = '';
        document.getElementById('phoneNumber_contact').value = '';
        document.getElementById('email_contact').value = '';
        document.getElementById('facebook_contact').value = '';
        document.getElementById('instagram_contact').value = '';

        fetch('http://localhost:7000/admin/contact/' + data.id, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}` },
            body: JSON.stringify(data)
        }).then( res => read());
    });
    document.getElementById('logout').addEventListener('click', e => {
        localStorage.setItem("token", {});
        window.location.href = '/admin/login';
    });
    
}
function read(){
    fetch('http://localhost:7000/admin/contact', {
        headers: {
            'Authorization': `Bearer ${localStorage.getItem("token")}`
            }
        })
    .then( res => res.json() )
    .then( data => {
        const lst = document.getElementById('contactLst');
        lst.remove();

        document.getElementById("contact").innerHTML += '<ul id="contactLst"></ul>';
        const lista = document.getElementById('contactLst');
        data.forEach( el => {
            lista.innerHTML += `<li>ID: ${el.id}, Phone number: ${el.phoneNumber}, Email: ${el.email}, Facebook: ${el.facebook}, Instagram: ${el.instagram}</li>`;
        });
    });
}