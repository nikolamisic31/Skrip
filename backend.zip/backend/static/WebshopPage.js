function init() {
    const token = localStorage.getItem("token");
  if(!token) window.location.href = "/admin/login";

    document.getElementById('webshopBtnGet').addEventListener('click', e => {
        e.preventDefault();
        read();
    })

    document.getElementById('webshopBtnPost').addEventListener('click', e => {
    e.preventDefault();

    const data = {
        product: document.getElementById('product').value,
        price: document.getElementById('price').value
    };

        document.getElementById('product').value = '';
        document.getElementById('price').value = '';

    fetch('http://localhost:7000/admin/webshop', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`},
        body: JSON.stringify(data)
        }).then( res => read());
        
    });

    document.getElementById('webshopBtnDelete').addEventListener('click', e => {
    e.preventDefault();

    const data = {
        id: document.getElementById('id').value
    };

    document.getElementById('id').value = '';

    fetch('http://localhost:7000/admin/webshop/' + data.id, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}` },
        body: JSON.stringify(data)
        }). then(res => read());

    });
    document.getElementById('webshopBtnPut').addEventListener('click', e => {
    e.preventDefault();

    const data = {
        id: document.getElementById('id_webshop').value,
        product: document.getElementById('product_webshop').value,
        price: document.getElementById('price_webshop').value,
    };
        document.getElementById('id_webshop').value = '';
        document.getElementById('product_webshop').value = '';
        document.getElementById('price_webshop').value = '';

    fetch('http://localhost:7000/admin/webshop/' + data.id, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}` },
        body: JSON.stringify(data)
        }).then( res => read());
    });
    document.getElementById('logout').addEventListener('click', e => {
        localStorage.setItem("token", {});
        window.location.href = '/admin/login';
    });
}
function read(){
    fetch('http://localhost:7000/admin/webshop', {
        headers: {
            'Authorization': `Bearer ${localStorage.getItem("token")}`
        }
    })
    .then( res => res.json() )
    .then( data => {
    const lst = document.getElementById('webshopLst');
    lst.remove();

    document.getElementById("webshop").innerHTML += '<ul id="webshopLst"></ul>';
    const lista = document.getElementById('webshopLst');
    data.forEach( el => {
        lista.innerHTML += `<li>ID: ${el.id}, Product: ${el.product}, Price: ${el.price}</li>`;
        });
    });
}