function init() {
const token = localStorage.getItem("token");
if(!token) window.location.href = "/admin/login";

document.getElementById('gymBtnGet').addEventListener('click', e => {
    e.preventDefault();
    read();
})

        document.getElementById('gymBtnPost').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            name: document.getElementById('name').value,
            address: document.getElementById('address').value
        };

        document.getElementById('name').value = '';
        document.getElementById('address').value = '';

        fetch('http://localhost:7000/admin/gym', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        }).then( res => read());
            
    });

    document.getElementById('gymBtnDelete').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            id: document.getElementById('id').value
        };

        document.getElementById('id').value = '';

        fetch('http://localhost:7000/admin/gym/' + data.id, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        }). then(res => read());

    });

    document.getElementById('gymBtnPut').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            id: document.getElementById('id_put').value,
            name: document.getElementById('name_put').value,
            address: document.getElementById('address_put').value
        };

        document.getElementById('id_put').value = '';
        document.getElementById('name_put').value = '';
        document.getElementById('address_put').value = '';

        fetch('http://localhost:7000/admin/gym/' + data.id, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        }).then( res => read());
    });
    
    document.getElementById('logout').addEventListener('click', e => {
        localStorage.setItem("token", {});
        window.location.href = '/admin/login';
    });
}
function read(){
    fetch('http://localhost:7000/admin/gym', {
        headers: {
            'Authorization': `Bearer ${localStorage.getItem("token")}`
        }
    })
    .then( res => res.json() )
    .then( data => {
        const lst = document.getElementById('gymLst');
        lst.remove();

        document.getElementById("gym").innerHTML += '<ul id="gymLst"></ul>';
        const lista = document.getElementById('gymLst');
        data.forEach( el => {
            lista.innerHTML += `<li>ID: ${el.id}, Name: ${el.name}, Address: ${el.address}</li>`;
        });
    });
}