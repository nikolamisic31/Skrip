function init() {
    const token = localStorage.getItem("token");
          if(!token) window.location.href = "/admin/login";
    document.getElementById('appointmentBtnGet').addEventListener('click', e => {
        e.preventDefault();
        read();
    })

    document.getElementById('appointmentBtnPost').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            appointement_time: document.getElementById('appointement_time').value,
            appointment_date: document.getElementById('appointment_date').value
        };

            document.getElementById('appointement_time').value = '';
            document.getElementById('appointment_date').value = '';

        fetch('http://localhost:7000/admin/appointments', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json',
                            'Authorization': `Bearer ${token}` },
            body: JSON.stringify(data)
        }).then( res => read());
            
    });

    document.getElementById('appointmentBtnDelete').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            id: document.getElementById('id').value
        };

        document.getElementById('id').value = '';

        fetch('http://localhost:7000/admin/appointment/' + data.id, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json',
                            'Authorization': `Bearer ${token}` },
            body: JSON.stringify(data)
        }). then(res => read());

    });
    document.getElementById('appointmentBtnPut').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            id: document.getElementById('id_appointment').value,
            appointement_time: document.getElementById('appointment_times').value,
            appointment_date: document.getElementById('appointment_dates').value

        };
            document.getElementById('id_appointment').value = '';
            document.getElementById('appointment_times').value = '';
            document.getElementById('appointment_dates').value = '';

        fetch('http://localhost:7000/admin/appointment/' + data.id, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json',
                            'Authorization': `Bearer ${token}` },
            body: JSON.stringify(data)
        }).then( res => read());
    });
    document.getElementById('logout').addEventListener('click', e => {
        localStorage.setItem("token", {});
        window.location.href = '/admin/login';
    });
}
 function read(){
    fetch('http://localhost:7000/admin/appointment', {
        headers: {
            'Authorization': `Bearer ${localStorage.getItem("token")}`
        }
    })
    .then( res => res.json() )
    .then( data => {
        const lst = document.getElementById('appointmentLst');
        lst.remove();

        document.getElementById("appointment").innerHTML += '<ul id="appointmentLst"></ul>';
        const lista = document.getElementById('appointmentLst');
        data.forEach( el => {
            lista.innerHTML += `<li>ID: ${el.id}, Appointment time: ${el.appointement_time}, Appointment date: ${el.appointment_date}</li>`;
        });
    });
 }