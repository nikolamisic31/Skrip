const token = localStorage.getItem("token");
    if(!token) window.location.href = "/admin/login";
    function init() {

    document.getElementById('clientBtnGet').addEventListener('click', e => {
        e.preventDefault();
        read();
    })

    document.getElementById('clientBtnPost').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            name: document.getElementById('name').value,
            surname: document.getElementById('surname').value,
            numberOfPhone: document.getElementById('numberOfPhone').value,
            email: document.getElementById('email').value
        };

        document.getElementById('name').value = '';
        document.getElementById('surname').value = '';
        document.getElementById('numberOfPhone').value = '';
        document.getElementById('email').value = '';

        fetch('http://localhost:7000/admin/client', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}` },
            body: JSON.stringify(data)
        }).then( res => read());
            
    });

    document.getElementById('clientBtnDelete').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            id: document.getElementById('id').value
        };

        document.getElementById('id').value = '';

        fetch('http://localhost:7000/admin/client/' + data.id, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}` },
            body: JSON.stringify(data)
        }). then(res => read());

    });
    document.getElementById('clientBtnPut').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            id: document.getElementById('id_client').value,
            name: document.getElementById('name_client').value,
            surname: document.getElementById('surname_client').value,
            numberOfPhone: document.getElementById('numberOfPhone_client').value,
            email: document.getElementById('email_client').value
        };

        document.getElementById('id_client').value = '';
        document.getElementById('name_client').value = '';
        document.getElementById('surname_client').value = '';
        document.getElementById('numberOfPhone_client').value = '';
        document.getElementById('email_client').value = '';

        fetch('http://localhost:7000/admin/client/' + data.id, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}` },
            body: JSON.stringify(data)
        }).then( res => read());
    });
    document.getElementById('logout').addEventListener('click', e => {
        localStorage.setItem("token", {});
        window.location.href = '/admin/login';
    });
}
function read(){
    fetch('http://localhost:7000/admin/client', {
        headers: {
            'Authorization': `Bearer ${localStorage.getItem("token")}`
            }
        })
    .then( res => res.json() )
    .then( data => {
        const lst = document.getElementById('clientLst');
        lst.remove();

        document.getElementById("client").innerHTML += '<ul id="clientLst"></ul>';
        const lista = document.getElementById('clientLst');
        data.forEach( el => {
            lista.innerHTML += `<li>ID: ${el.id}, Surname: ${el.surname}, Number of phone: ${el.numberOfPhone}, Email: ${el.email}</li>`;
        });
    });
}