const token = localStorage.getItem("token");
if(!token) window.location.href = "/admin/login";
function init() {

document.getElementById('membership_cardBtnGet').addEventListener('click', e => {
e.preventDefault();
read();
})

document.getElementById('membership_cardBtnPost').addEventListener('click', e => {
e.preventDefault();

const data = {
  name: document.getElementById('name').value,
  number_of_arrivals: document.getElementById('number_of_arrivals').value,
  sale: document.getElementById('sale').value
};

document.getElementById('name').value = '';
document.getElementById('number_of_arrivals').value = '';
document.getElementById('sale').value = '';

fetch('http://localhost:7000/admin/membership_cards', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json',
                  'Authorization': `Bearer ${token}` },
  body: JSON.stringify(data)
}).then( res => read());
  
});

document.getElementById('membership_cardBtnDelete').addEventListener('click', e => {
e.preventDefault();

const data = {
  id: document.getElementById('id').value
};

document.getElementById('id').value = '';

fetch('http://localhost:7000/admin/membership_card/' + data.id, {
  method: 'DELETE',
  headers: { 'Content-Type': 'application/json',
                  'Authorization': `Bearer ${token}` },
  body: JSON.stringify(data)
}). then(res => read());

});
  document.getElementById('membership_cardBtnPut').addEventListener('click', e => {
    e.preventDefault();

    const data = {
      id: document.getElementById('id_membership_card').value,
      name: document.getElementById('name_membership_card').value,
      number_of_arrivals: document.getElementById('number_of_arrivals__membership_card').value,
      sale: document.getElementById('sale_membership_card').value,
    };

    document.getElementById('id_membership_card').value = '';
    document.getElementById('name_membership_card').value = '';
    document.getElementById('number_of_arrivals__membership_card').value = '';
    document.getElementById('sale_membership_card').value = '';

    fetch('http://localhost:7000/admin/membership_card/' + data.id, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json',
                      'Authorization': `Bearer ${token}` },
      body: JSON.stringify(data)
    }).then( res => read());
  });
  document.getElementById('logout').addEventListener('click', e => {
    localStorage.setItem("token", {});
    window.location.href = '/admin/login';
});

}
function read(){
    fetch('http://localhost:7000/admin/membership_card', {
      headers: {
          'Authorization': `Bearer ${localStorage.getItem("token")}`
      }
    })
    .then( res => res.json() )
    .then( data => {
    const lst = document.getElementById('membership_cardLst');
    lst.remove();

    document.getElementById("membership_card").innerHTML += '<ul id="membership_cardLst"></ul>';
    const lista = document.getElementById('membership_cardLst');
    data.forEach( el => {
      lista.innerHTML += `<li>ID: ${el.id}, Name: ${el.name}, Number of arrivals: ${el.number_of_arrivals}, Sale: ${el.sale}</li>`;
    });
  });
}