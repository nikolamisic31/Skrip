const token = localStorage.getItem("token");
if(!token) window.location.href = "/admin/login";
function init() {

  document.getElementById('workpeopleBtnGet').addEventListener('click', e => {
    e.preventDefault();
    read();
    })

    document.getElementById('workpeopleBtnPost').addEventListener('click', e => {
    e.preventDefault();

    const data = {
      name: document.getElementById('name').value,
      surname: document.getElementById('surname').value,
      age: document.getElementById('age').value,
      sex: document.getElementById('sex').value,
      date_start_working: document.getElementById('date_start_working').value
    };

      document.getElementById('name').value = '';
      document.getElementById('surname').value = '';
      document.getElementById('age').value = '';
      document.getElementById('date_start_working').value = '';

    fetch('http://localhost:7000/admin/workpeople', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json',
                      'Authorization': `Bearer ${token}` },
      body: JSON.stringify(data)
    }).then( res => read());
      
    });

    document.getElementById('workpeopleBtnDelete').addEventListener('click', e => {
    e.preventDefault();

    const data = {
      id: document.getElementById('id').value
    };

    document.getElementById('id').value = '';

    fetch('http://localhost:7000/admin/workpeople/' + data.id, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json',
                      'Authorization': `Bearer ${token}`},
      body: JSON.stringify(data)
    }). then(res => read());

    });
    document.getElementById('workpeopleBtnPut').addEventListener('click', e => {
    e.preventDefault();

    const data = {
      id: document.getElementById('id_workpeople').value,
      name: document.getElementById('name_workpeople').value,
      surname: document.getElementById('surname_workpeople').value,
      age: document.getElementById('age_workpeople').value,
      sex: document.getElementById('sex_workpeople').value,
      date_start_working: document.getElementById('date_start_working_workpeople').value

    };
      document.getElementById('id_workpeople').value = '';
      document.getElementById('name_workpeople').value = '';
      document.getElementById('surname_workpeople').value = '';
      document.getElementById('age_workpeople').value = '';
      document.getElementById('sex_workpeople').value = '';
      document.getElementById('date_start_working_workpeople').value = '';

    fetch('http://localhost:7000/admin/workpeople/' + data.id, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json',
                      'Authorization': `Bearer ${token}`},
      body: JSON.stringify(data)
    }).then( res => read());
  });
  document.getElementById('logout').addEventListener('click', e => {
    localStorage.setItem("token", {});
    window.location.href = '/admin/login';
});
}
function read(){
    fetch('http://localhost:7000/admin/workpeople', {
      headers: {
          'Authorization': `Bearer ${localStorage.getItem("token")}`
      }
    })
    .then( res => res.json() )
    .then( data => {
    const lst = document.getElementById('workpeopleLst');
    lst.remove();

    document.getElementById("workpeople").innerHTML += '<ul id="workpeopleLst"></ul>';
    const lista = document.getElementById('workpeopleLst');
    data.forEach( el => {
      lista.innerHTML += `<li>ID: ${el.id}, Name: ${el.name}, Surname: ${el.surname}, Age: ${el.age}, Sex: ${el.sex}, Date start working: ${el.date_start_working}</li>`;
    });
  });
}