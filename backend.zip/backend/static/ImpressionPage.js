function init() {
    const token = localStorage.getItem("token");
    if(!token) window.location.href = "/admin/login";
    
    document.getElementById('impressionBtnGet').addEventListener('click', e => {
    e.preventDefault();
    read();
    })

    document.getElementById('impressionBtnPost').addEventListener('click', e => {
    e.preventDefault();

    const data = {
        comment: document.getElementById('comment').value,
        time_impression: document.getElementById('time_impression').value,
        date_impression: document.getElementById('date_impression').value
    };

    document.getElementById('comment').value = '';
    document.getElementById('time_impression').value = '';
    document.getElementById('date_impression').value = '';


    fetch('http://localhost:7000/admin/impression', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}` },
        body: JSON.stringify(data)
    }).then( res => read());
        
    });

    document.getElementById('impressionBtnDelete').addEventListener('click', e => {
    e.preventDefault();

    const data = {
        id: document.getElementById('id').value
    };

    document.getElementById('id').value = '';

    fetch('http://localhost:7000/admin/impression/' + data.id, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}` },
        body: JSON.stringify(data)
    }). then(res => read());

    });

    document.getElementById('impressionBtnPut').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            id: document.getElementById('id_impressions').value,
            comment: document.getElementById('comment_impressions').value,
            time_impression: document.getElementById('time_impressions').value,
            date_impression: document.getElementById('date_impressions').value
        };

        document.getElementById('id_impressions').value = '';
        document.getElementById('comment_impressions').value = '';
        document.getElementById('time_impressions').value = '';
        document.getElementById('date_impressions').value = '';

        fetch('http://localhost:7000/admin/impression/' + data.id, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json',
                            'Authorization': `Bearer ${token}`
                        },
            body: JSON.stringify(data)
        }).then( res => read());
    });
    document.getElementById('logout').addEventListener('click', e => {
        localStorage.setItem("token", {});
        window.location.href = '/admin/login';
    });
}
function read(){
    fetch('http://localhost:7000/admin/impression', {
        headers: {
            'Authorization': `Bearer ${localStorage.getItem("token")}`
        }
    })
    .then( res => res.json() )
    .then( data => {
    
        const lst = document.getElementById('impressionLst');
    lst.remove();

    document.getElementById("impression").innerHTML += '<ul id="impressionLst"></ul>';
    const lista = document.getElementById('impressionLst');
    data.forEach( el => {
        lista.innerHTML += `<li>ID: ${el.id}, Comment: ${el.comment}, Time impression: ${el.time_impression}, Date impression: ${el.date_impression}</li>`;
        });
    });
}