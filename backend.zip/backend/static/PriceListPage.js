function init() {
    const token = localStorage.getItem("token");
    if(!token) window.location.href = "/admin/login";

    document.getElementById('pricelistBtnGet').addEventListener('click', e => {
    e.preventDefault();
    read();
    })

    document.getElementById('pricelistBtnPost').addEventListener('click', e => {
    e.preventDefault();

    const data = {
        price: document.getElementById('price').value,
    };

    document.getElementById('price').value = '';

    fetch('http://localhost:7000/admin/pricelist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}` },
        body: JSON.stringify(data)
    }).then( res => read());
        
    });

    document.getElementById('pricelistBtnDelete').addEventListener('click', e => {
    e.preventDefault();

    const data = {
        id: document.getElementById('id').value
    };

    document.getElementById('id').value = '';

    fetch('http://localhost:7000/admin/pricelist/' + data.id, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}` },
        body: JSON.stringify(data)
    }). then(res => read());

    });
    document.getElementById('pricelistBtnPut').addEventListener('click', e => {
    e.preventDefault();

    const data = {
        id: document.getElementById('id_pricelist').value,
        price: document.getElementById('price_pricelist').value,
    };

    document.getElementById('id_pricelist').value = '';
    document.getElementById('price_pricelist').value = '';

    fetch('http://localhost:7000/admin/pricelist/' + data.id, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}` },
        body: JSON.stringify(data)
        }).then( res => read());
    });
    document.getElementById('logout').addEventListener('click', e => {
        localStorage.setItem("token", {});
        window.location.href = '/admin/login';
    });

}
function read(){
    fetch('http://localhost:7000/admin/pricelist', {
        headers: {
            'Authorization': `Bearer ${localStorage.getItem("token")}`
        }
    })
    .then( res => res.json() )
    .then( data => {
    const lst = document.getElementById('pricelistLst');
    lst.remove();

    document.getElementById("pricelist").innerHTML += '<ul id="pricelistLst"></ul>';
    const lista = document.getElementById('pricelistLst');
    data.forEach( el => {
        lista.innerHTML += `<li>ID: ${el.id}, Price: ${el.price}</li>`;
        });
    });
}